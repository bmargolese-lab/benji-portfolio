# Benji Margolese Portfolio

Static one-page website, ready for GitHub and Cloudflare Pages.

## Publish
1. Create a new GitHub repository, e.g. `benji-portfolio`.
2. Upload `index.html` and the `assets` folder to the repository root.
3. In Cloudflare: Workers & Pages → Create → Pages → Connect to Git → select the repository.
4. Framework preset: None. Build command: leave blank. Build output directory: `/` (repository root).
5. Deploy. In the Pages project, Custom domains → add `benjimargolese.com` and follow Cloudflare's DNS instructions.
6. Preserve the existing `app.benjimargolese.com` DNS record and its separate deployment; don't replace it with the portfolio project.

## Before launch
- Replace the decorative hero background with a real cover photo if desired.
- Replace the initials avatar with Benji's actual headshot. Add `assets/headshot.jpg` and replace the avatar DIV with `<img class="avatar" src="assets/headshot.jpg" alt="Benji Margolese">`.
- Confirm the résumé is the intended final version (this file is page 1 of the uploaded combined résumé and cover-letter PDF).
- Review job descriptions and HiBob business metrics for final approval.
- The website is independent of the existing `/site` product overview.
